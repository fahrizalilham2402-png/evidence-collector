const fs = require("fs");
const path = require("path");
const xml2js = require("xml2js");

const kmlDir = "kml";
const MAX_DISTANCE = 50;

// Haversine distance
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000; // meters
  const toRad = x => x * Math.PI / 180;
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δφ = toRad(lat2 - lat1);
  const Δλ = toRad(lon2 - lon1);
  const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Evidence type matching
function matchesEvidenceType(placemarkName, evidenceType) {
  const name = (placemarkName || '').toUpperCase();
  const et = (evidenceType || '').toUpperCase();
  let result = false;
  switch (et) {
    case 'TIANG':
      result = name.includes('TB') || name.includes('TIANG') || name.includes('COBA');
      break;
    case 'ODP':
      result = name.includes('ODP');
      break;
    case 'ODC':
      result = name.includes('ODC');
      break;
    default:
      result = true;
  }
  console.log(`🔍 Checking: "${name}" vs "${evidenceType}" -> ${result}`);
  return result;
}

async function testODP() {
  console.log("\n=== ODP DIAGNOSTIC TEST ===\n");
  
  // Test coordinates (example - adjust these based on your GPS reading)
  const testLat = -7.050193845054116;  // From ODP.kml description
  const testLon = 110.43938096286362;
  
  console.log(`📍 Testing with coordinates: lat=${testLat}, lon=${testLon}`);
  console.log(`🧾 Testing with evidenceType: 'ODP'\n`);

  const filePath = path.join(kmlDir, "ODP.kml");
  const xml = fs.readFileSync(filePath, "utf-8");
  const kmlObject = await xml2js.parseStringPromise(xml);

  const doc = kmlObject.kml?.Document?.[0];
  let placemarks = [];
  if (doc?.Placemark) placemarks = doc.Placemark;
  else if (doc?.Folder) {
    doc.Folder.forEach(f => { if (f.Placemark) placemarks = placemarks.concat(f.Placemark); });
  }

  console.log(`📄 Found ${placemarks.length} placemarks in ODP.kml\n`);

  for (const pm of placemarks) {
    const pmName = pm.name?.[0] || '(no name)';
    console.log(`\nProcessing placemark: "${pmName}"`);
    
    // Check type match
    const typeMatch = matchesEvidenceType(pmName, 'ODP');
    if (!typeMatch) {
      console.log(`  ❌ Type mismatch - skipping this placemark`);
      continue;
    }
    console.log(`  ✅ Type match - continuing`);

    const coords = pm.Point?.[0]?.coordinates?.[0];
    if (!coords) {
      console.log(`  ❌ No coordinates found`);
      continue;
    }

    const parts = coords.split(',').map(s => parseFloat(s.trim()));
    const [pmLon, pmLat] = parts;
    console.log(`  📍 Placemark coords: lat=${pmLat}, lon=${pmLon}`);

    if (isNaN(pmLat) || isNaN(pmLon)) {
      console.log(`  ❌ Invalid coordinates`);
      continue;
    }

    const distance = haversine(testLat, testLon, pmLat, pmLon);
    console.log(`  📏 Distance: ${distance.toFixed(2)} meters`);
    
    if (distance > MAX_DISTANCE) {
      console.log(`  ❌ Distance exceeds MAX_DISTANCE (${MAX_DISTANCE}m) - SKIPPING`);
    } else {
      console.log(`  ✅ Distance within range - THIS SHOULD MATCH!`);
    }
  }

  console.log("\n=== END DIAGNOSTIC ===\n");
}

testODP().catch(err => console.error("Error:", err));
